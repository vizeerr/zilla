import { motion } from "framer-motion";
import React from 'react';
import cross from "@/assets/cross.png";
import cam from "@/assets/cam.png"
import Image from "next/image";
const TickerModel = ({openTic,setOpenTic}) => {
    const handleClose = (e) => {
        if (e.target.id === "background") {
          setOpenTic(false);
        }
      }
      
  return (
    <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: open ? 1 : 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className={`${
            openTic ? "flex " : "hidden"
          } bg-[#00000080] fixed z-20  justify-center items-center w-full h-screen  top-0`}
          onClick={(e) => handleClose(e)}
          id="background">
            
            <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: openTic ? 1 : 0 }}
                    exit={{ opacity: 0, y: -50 }}
                    transition={{ duration: 0.3 }}
                    id="box"
                    className={`${
                        openTic ? "block" : "hidden"
                    } bg-[#1B1C1E] 2xl:w-[50rem] lg:w-[50rem] md:w-[40rem] w-[90vw] h-min md:rounded-[1.7rem] rounded-[6vw]`}>

                    <div className="w-full flex justify-end md:pt-3 pt-3 md:pe-3 pe-3">
                        <div className="2xl:w-9 md:w-7 w-[6vw] cursor-pointer anim">
                
                            <Image
                                src={cross}
                                className=" w-full "
                                onClick={() => setOpenTic(false)}
                                alt=""
                            />
                        </div>
                    </div>

                    <div className="2xl:px-16 md:px-10 px-5">
                        
                        <p className="2xl:text-3xl text-white font-[700] font-montserrat text-center" >Choose How Many <span className="text-primary">Ticker</span>  You Want to Buy</p>
                        <p className="mt-6 font-montserrat leading-tight text-center font-[600] text-white border-s-primary md:border-s-[6px] border-s-[3px] md:py-1  2xl:text-lg text-2xl text-[3vw]"><span className="text-primary">Disclaimer</span > : <span className="opacity-40"> Its optional, but buying a small amount of coins can help</span> protect your coin from snipers</p>
                        
                        <div className="w-full flex justify-end my-5">
                            <p className="bg-primary text-[#222227] text-base font-bebasneue w-32 py-0.5 text-center rounded-full">Switch To Ticker</p>
                        </div>
                        <div className="bg-[#111111] shadow-2xl px-8 w-full py-6 rounded-xl">
                            <div>
                                <input type="number" className="w-full bg-transparent text-white font-montserrat font-[700] text-5xl border-0 focus:outline-none" placeholder="0 Enter Amount" />
                                <p className="font-bebasneue">you receive : [x] Ticker</p>
                            </div>

                        </div>

                        
                    </div>
                    <div className="">
                        <p className="text-[#1B1C1E] anim bg-primary round 2xl:text-7xl md:text-5xl text-[8vw] leading-none pt-3 text-center mx-auto 2xl:w-[30rem] md:w-[20rem] w-[80vw] 2xl:my-12 my-7 md:rounded-2xl rounded-[3vw]">POST</p>
                    </div>

            </motion.div>
            
      
    </motion.div>
  )
}

export default TickerModel
