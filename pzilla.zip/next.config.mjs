/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['ipfs.io'],
      },
      optimizeFonts:false,
}

;

export default nextConfig;
