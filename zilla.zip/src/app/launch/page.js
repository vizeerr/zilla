import TopNavbar from '@/components/TopNavbar'
import React from 'react'

import LaunchForm from '@/components/launch/LaunchForm'
import LaunchFooter from '@/components/launch/LaunchFooter'

const page = () => {
  return (
    <div className='bg-[#121215]'>
     
      <LaunchForm/>      
    </div>
  )
}

export default page
